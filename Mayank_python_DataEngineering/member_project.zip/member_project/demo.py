"""
demo.py
Run this BEFORE packaging to test your logic:
    python demo.py
"""

from my_processor import process_raw_members, filter_members_by_domain, get_all_names

raw_members = [
    {"name": "John Doe", "email": "john.doe@example.com", "phone": "555-0101"},
    {"name": "Jane Smith", "email": "jane.smith@example.com", "phone": "555-0102"},
    {"name": "InvalidData", "email": "not-an-email", "phone": "555-0103"},
]

if __name__ == "__main__":
    members = process_raw_members(raw_members)

    print("\nAll processed members:")
    for m in members:
        print(" -", m)

    print("\nNames only (map/lambda):", get_all_names(members))

    example_com_members = filter_members_by_domain(members, "example.com")
    print("Members @example.com (filter/lambda):", example_com_members)
