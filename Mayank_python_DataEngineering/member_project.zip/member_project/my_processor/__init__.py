"""my_processor package: a small member-data cleaning & management utility."""

from .core import Member, process_raw_members, filter_members_by_domain, get_all_names
from .utils import InvalidMemberDataError

__all__ = [
    "Member",
    "process_raw_members",
    "filter_members_by_domain",
    "get_all_names",
    "InvalidMemberDataError",
]
